#include <cmath>

int main()
{
    double x = std::log(2);
    return x == 0;
}
