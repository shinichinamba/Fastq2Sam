typedef unsigned int uint128_t __attribute__((mode(TI)));

int main()
{
    uint128_t x = 5;
    return 0;
}
